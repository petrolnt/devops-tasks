#!/usr/bin/python
import time       
import csv


def main() : 
	while True:
		with open('ph_ec_val.csv','r') as f : 
			time.sleep(1)
			data = csv.reader(f)
			for row in data:
				print(row)

if __name__ == '__main__':
	main()
