import paho.mqtt.client as mqttClient
import sys
import time

class MqttClient:
  def __init__(self, host, user, password, topics, topic_listeners):
    self.connected = False
    self._host = host
    self.client = mqttClient.Client("atat")
    self.client.qos = 1
    self.client.username_pw_set(user, password=password)
    self.client.on_connect = self.on_connect
    self._topics = topics
    if (topic_listeners is not None):
      self.__set_listeners(topic_listeners)

  def connect(self):
    try:
      self.client.connect(self._host)
      print(f'Connected to {self._host}')
    except:
      print('Exception in connecting to mqtt server')
      sys.exit(1)

    try:
      self.client.loop_start()
    except:
      print('Exception in starting loop')
      sys.exit(1)

    while self.connected != True:
      time.sleep(0.1)

    try:
      self.client.subscribe(self._topics)
      print('Subscribed to topics:' + self._topics)
    except:
      print('Exception in subscription to topics:' + self._topics)
      sys.exit(1)

    try:
      while True:
          time.sleep(1)
    except KeyboardInterrupt:
      print("exiting")
      self.client.disconnect()
      self.client.loop_stop()

  def on_connect(self, client, userdata, flags, rc):
    if rc == 0:
        print("Connected to broker")
        self.connected = True
    else:
        print("Connection failed")

  def __set_listeners(self, topic_listeners):
    for topic, method in topic_listeners.items():
      self.client.message_callback_add(topic, method)

  def publish(self, topic, msg):
    self.client.publish(topic, msg, 1)
    print(f"published msg {msg} to {topic}")

