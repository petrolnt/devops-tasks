#!/usr/bin/python
# -*- coding: utf-8 -*-
import os, sys
# add /Sources to the PYTHONPATH
sys.path.append(os.path.join("Sources"))
from yocto_api import *
from yocto_temperature import *
from yocto_carbondioxide import *
from yocto_humidity import *
from yocto_pressure import *

def die(msg):
  print('exit witth message: ' + msg)
  sys.exit(msg + ' (check connection)')

def main():
  errmsg = YRefParam()
  target = 'any'

  print('connected to a dataflow provider')

  # Setup the API to for the device with its ip
  if YAPI.RegisterHub("192.168.3.150", errmsg) != YAPI.SUCCESS:
      sys.exit("init error" + errmsg.value)

  if target == 'any':
      # retreive all the sensors
      sensor = YCarbonDioxide.FirstCarbonDioxide()
      sensor2 = YTemperature.FirstTemperature()
      sensor3 = YHumidity.FirstHumidity()
      sensor4 = YPressure.FirstPressure()
      if sensor is None:
          die('No module connected')
  else:
      sensor = YCarbonDioxide.FindCarbonDioxide(target + '.carbonDioxide')

  if not (sensor.isOnline()):
      die('device not connected')

  while sensor.isOnline():
      print(sensor.get_currentValue())  # CO2 in ppm
      print(sensor2.get_currentValue()) # Temperature in C
      print(sensor3.get_currentValue()) # Humidity in %HR
      print(sensor4.get_currentValue()) # Pressure in mbar
      YAPI.Sleep(1000)

  YAPI.FreeAPI()

class Ambient:
  def __init__(self, host):
    errmsg = YRefParam()

    if YAPI.RegisterHub(host, errmsg) != YAPI.SUCCESS:
      sys.exit("Error in YAPI.RegisterHub: " + errmsg.value)
    
    self.co2_sensor = YCarbonDioxide.FirstCarbonDioxide()
    self.temperature_sensor = YTemperature.FirstTemperature()
    self.humidity_sensor = YHumidity.FirstHumidity()
    self.pressure_sensor = YPressure.FirstPressure()

  def get_data(self):
    if not (self.co2_sensor.isOnline()):
      print('co2_sensor does not connected')
      return {}
    
    return {
      'label': 'ambient',
      'co2': self.co2_sensor.get_currentValue(),
      'temperature': self.temperature_sensor.get_currentValue(),
      'humidity': self.humidity_sensor.get_currentValue(),
      'pressure': self.pressure_sensor.get_currentValue(),
      }

  def get_value_or_empty(self, sensor):
    if not (sensor.isOnline()):
      print("{} does not connected".format(sensor))
      return None

    return sensor.get_currentValue()

  def close(self):
    YAPI.FreeAPI()
