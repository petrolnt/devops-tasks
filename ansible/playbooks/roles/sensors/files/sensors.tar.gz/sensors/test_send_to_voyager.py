import time
import sys
import datetime
from datetime import datetime
import ph_ec
from ph_ec import AtlasI2C
import ambient
from ambient import Ambient
import dataflow_provider
from dataflow_provider import DataFlowProvider

df = DataFlowProvider("192.168.3.152", "sensors", "1q2w3e4r", "facility/sensors/data")
df.connect()

data = {}

try:
  while(True):
    try:
      data['label'] = 'test'
      data['temperature'] = 28.0
      data['ec'] = 7.908
      data['ph'] = 1526
      data['co2'] = 643
      data['humidity'] = 41.3
      data['pressure'] = 971.78

      df.send(data)
      time.sleep(5)
    except ValueError as ex:
      print('Exception in getting data: ' + str(ex))
except KeyboardInterrupt:
  df.disconnect()
  print('Exiting')
  sys.exit(0)

