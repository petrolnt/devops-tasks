import sys
sys.path.append('/home/pi/Desktop/scripts/')
import time
import json
import threading
from threading import Thread
import mqtt_client
from mqtt_client import MqttClient

class DataFlowProvider:

  def __init__(self, host, login, password, topic):
    self.transport = MqttClient(host, login, password, None, None)
    self.topic = "facility/sensors/data"

  def connect(self):
    clientloop_thread = Thread(None, self.transport.connect)
    clientloop_thread.daemon = True
    clientloop_thread.start()

  def send(self, data):
    self.transport.publish(self.topic, json.dumps(data))

  def disconnect(self):
    self.transport.disconnect()
