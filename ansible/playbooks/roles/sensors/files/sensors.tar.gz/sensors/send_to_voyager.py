import time
import sys
import datetime
from datetime import datetime
import ph_ec
from ph_ec import AtlasI2C
import ambient
from ambient import Ambient
import dataflow_provider
from dataflow_provider import DataFlowProvider

df = DataFlowProvider("192.168.3.152", "sensors", "1q2w3e4r", "facility/sensors/data")
df.connect()

ambient = Ambient("192.168.3.150")

ec_device = AtlasI2C()
ec_device_addr = ec_device.set_i2c_address(100) # EC sensor address
ph_device = AtlasI2C()
ph_device_addr = ph_device.set_i2c_address(99) # PH sensor address

try:
  while(True):
    try:
      data = ambient.get_data()
      data['ec'] = float(ec_device.query("R"))
      time.sleep(1)
      data['ph'] = float(ph_device.query("R"))
      df.send(data)
      time.sleep(5)
    except ValueError as ex:
      print('Exception in getting data: ' + str(ex))
except KeyboardInterrupt:
  df.disconnect()
  ec_device.close()
  ph_device.close()
  ambient.close()
  print('Exiting')
  sys.exit(0)

